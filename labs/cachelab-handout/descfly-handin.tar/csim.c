#include "cachelab.h"
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

typedef struct {
    unsigned int valid;
    unsigned int tag;
    unsigned int times;
} cacheLine, *cacheLinePtr;

typedef struct {
    cacheLinePtr lines;
} cacheSet, *cacheSetPtr;

typedef struct {
    cacheSetPtr sets;
} cache, *cachePtr;

static cachePtr cacheBase;
static unsigned int numberOfSets;
static unsigned int numberOfLines;

static void initCache(int, int);
static void initCacheLines(cacheLinePtr);
static void printCache();
static void printSet(cacheSetPtr);
static void printLine(cacheLinePtr);

static void initCache(int s, int E) {
    numberOfSets = s;
    numberOfLines = E;
    cacheBase = (cachePtr) malloc(s*sizeof(cacheSet));
    if (cacheBase == NULL) {
        printf("malloc error\n");
        exit(1);
    }

    cacheSetPtr setPtr = (cacheSetPtr) cacheBase;
    for (int i = 0; i < s; ++i) {
        setPtr->lines = (cacheLinePtr) malloc(E*sizeof(cacheLine));
        if (setPtr->lines == NULL) {
            printf("malloc error\n");
            exit(1);
        }
        initCacheLines(setPtr->lines);
        setPtr += 1;
    }
}

void initCacheLines(cacheLinePtr lineBase) {
    cacheLinePtr linePtr = lineBase;
    for (int i = 0; i < numberOfLines; ++i) {
        linePtr->valid = 0;
        linePtr->tag = 0;
        linePtr->times = 0;
        linePtr += 1;
    }
}

void printCache() {
    printf("Valid\t\tTag\t\ttimes\n");
    cacheSetPtr setPtr = (cacheSetPtr) cacheBase;
    for (int i = 0; i < numberOfSets; ++i) {
        printSet(setPtr);
        setPtr += 1;
    }
}

void printSet(cacheSetPtr setBase) {
    cacheSetPtr setPtr = setBase;
    for (int i = 0; i < numberOfLines; ++i) {
        printLine(setPtr->lines);
        setPtr += 1;
    }
}

void printLine(cacheLinePtr lineBase) {
   cacheLinePtr linePtr = lineBase; 
   printf("%d\t%d\t%d\n", linePtr->valid, linePtr->tag, linePtr->times);
}

int main(int argc, char* argv[])
{
    int ch;
    int s, E, b;
    while ((ch = getopt(argc, argv, "s:E:b:t:")) != -1) {
        switch (ch) {
            case 's':
                s = atoi(optarg);
                break;
            case 'E':
                E = atoi(optarg);
                break;
            case 'b':
                b = atoi(optarg);
                break;
            case 't':
                printf("Will open the file: %s\n", optarg);
                break;
            case '?':
            default:
                exit(1);
        }
    }

    initCache(s, E);
    printCache();
    printf("b=%d\n", b);
    // printSummary(0, 0, 0);
    return 0;
}
